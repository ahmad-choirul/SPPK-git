-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2017 at 12:26 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sppk`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` varchar(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
('AD001', 'halo', 'halo');

-- --------------------------------------------------------

--
-- Table structure for table `hasil_hitung`
--

CREATE TABLE `hasil_hitung` (
  `no` int(11) NOT NULL,
  `nilai` double NOT NULL,
  `kinerja` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `hitung_lahan`
--

CREATE TABLE `hitung_lahan` (
  `no` varchar(10) NOT NULL,
  `nilai` double NOT NULL,
  `kinerja` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kriteria`
--

CREATE TABLE `kriteria` (
  `id` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `bobot` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kriteria`
--

INSERT INTO `kriteria` (`id`, `nama`, `bobot`) VALUES
('KR001', 'Harga', 5),
('KR002', 'Luas Tanah', 4),
('KR003', 'Jarak dengan Kases Jalan', 2),
('KR004', 'Kesuburan Tanah', 3),
('KR005', 'SDM', 4),
('KR006', 'Alat', 3),
('KR007', 'Lokasi', 2);

-- --------------------------------------------------------

--
-- Table structure for table `kriteria_lahan`
--

CREATE TABLE `kriteria_lahan` (
  `no` varchar(15) NOT NULL,
  `id_kriteria` varchar(10) NOT NULL,
  `id_himpunan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kriteria_lahan`
--

INSERT INTO `kriteria_lahan` (`no`, `id_kriteria`, `id_himpunan`) VALUES
('0000000002', 'KR001', 'SB002'),
('0000000002', 'KR002', 'SB006'),
('0000000002', 'KR003', 'SB014'),
('0000000002', 'KR004', 'SB016'),
('0000000002', 'KR005', 'SB022'),
('0000000002', 'KR006', 'SB030'),
('0000000002', 'KR007', 'SB032'),
('0000000001', 'KR001', 'SB002'),
('0000000001', 'KR002', 'SB010'),
('0000000001', 'KR003', 'SB013'),
('0000000001', 'KR004', 'SB016'),
('0000000001', 'KR005', 'SB024'),
('0000000001', 'KR006', 'SB028'),
('0000000001', 'KR007', 'SB034');

-- --------------------------------------------------------

--
-- Table structure for table `lahan`
--

CREATE TABLE `lahan` (
  `no` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lahan`
--

INSERT INTO `lahan` (`no`, `nama`, `alamat`) VALUES
('0000000001', 'hai', 'dimana'),
('0000000002', 'lahan 2', 'ndak tau');

-- --------------------------------------------------------

--
-- Table structure for table `subkriteria`
--

CREATE TABLE `subkriteria` (
  `id` varchar(10) NOT NULL,
  `id_kriteria` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `bobot` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subkriteria`
--

INSERT INTO `subkriteria` (`id`, `id_kriteria`, `nama`, `bobot`) VALUES
('SB001', 'KR001', 'diatas 1 milyar', 1),
('SB002', 'KR001', '750 juta-1 milyar', 2),
('SB003', 'KR001', '500 juta-750 juta', 3),
('SB004', 'KR002', 'diatas 100 hektar', 5),
('SB005', 'KR002', '100 hektar - 75 hektar', 4),
('SB006', 'KR002', '75 hektar - 50 hektar', 3),
('SB007', 'KR001', '250 juta - 500 juta', 4),
('SB008', 'KR001', 'dibawah 250', 5),
('SB009', 'KR002', '50 hektar - 25 hektar', 2),
('SB010', 'KR002', 'kurang dari 25 hektar', 1),
('SB011', 'KR003', 'Sangat dekat', 5),
('SB012', 'KR003', 'lumayan dekat', 4),
('SB013', 'KR003', 'Cukup', 3),
('SB014', 'KR003', 'lumayan jauh', 2),
('SB015', 'KR003', 'Sangat jauh', 1),
('SB016', 'KR004', 'Sangat Baik', 5),
('SB017', 'KR004', 'Baik', 4),
('SB018', 'KR004', 'Cukup', 3),
('SB019', 'KR004', 'Buruk', 2),
('SB020', 'KR004', 'Sangat Buruk', 1),
('SB021', 'KR005', 'Sangat Banyak', 5),
('SB022', 'KR005', 'Banyak', 4),
('SB023', 'KR005', 'Cukup', 3),
('SB024', 'KR005', 'Sedikit', 2),
('SB025', 'KR005', 'Sangat Sedikit', 1),
('SB026', 'KR006', 'mudah terjangkau', 5),
('SB027', 'KR006', 'terjangkau', 4),
('SB028', 'KR006', 'lumayan sulit terjangkau', 3),
('SB029', 'KR006', 'susah terjangkau', 2),
('SB030', 'KR006', 'tidak terjangkau', 1),
('SB031', 'KR007', 'siap tanam', 5),
('SB032', 'KR007', 'pembenahan kecil', 4),
('SB033', 'KR007', 'perlu perbaikan besar', 3),
('SB034', 'KR007', 'lahan rusak', 2),
('SB035', 'KR007', 'lahan sangat rusak', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hasil_hitung`
--
ALTER TABLE `hasil_hitung`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `hitung_lahan`
--
ALTER TABLE `hitung_lahan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lahan`
--
ALTER TABLE `lahan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `subkriteria`
--
ALTER TABLE `subkriteria`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
